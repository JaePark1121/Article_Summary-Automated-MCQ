from django.db import models


class Document(models.Model):
    file = models.CharField(max_length=255)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    latency_ms = models.IntegerField(null=True)
    thread_id = models.CharField(max_length=255, null=True, blank=True)
    remote_file_id = models.CharField(max_length=255, null=True, blank=True),
    s3_key       = models.CharField(max_length=300, null=True, blank=True)  
    
    status = models.CharField(
        max_length=50,
        default="pending", 
        help_text="Processing status of the document",
    )
    created_at = models.DateTimeField(auto_now_add=True)




    def __str__(self):
        return self.file.name


class Message(models.Model):
    document = models.ForeignKey(Document, on_delete=models.CASCADE)
    role = models.CharField(max_length=20)  # "assistant" / "user"
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.role}: {self.content[:40]}..."

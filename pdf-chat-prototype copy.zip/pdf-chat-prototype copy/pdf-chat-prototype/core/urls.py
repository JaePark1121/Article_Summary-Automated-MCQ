from django.urls import path
from . import views

urlpatterns = [
path("", views.upload_page, name="home"), 
path("presign/", views.presign, name="presign"),
path("notify-upload/", views.notify_upload, name="notify_upload"),
path("summarize/fast/<int:doc_id>/", views.summarize_fast, name="summarize_fast"),
path("summarize/assistant/<int:doc_id>/", views.summarize, name="summarize_assistant"),
path("poll_run/<int:doc_id>/", views.poll_run, name="poll_run"),
path("chat/<int:doc_id>/", views.chat, name="chat"),

    
]

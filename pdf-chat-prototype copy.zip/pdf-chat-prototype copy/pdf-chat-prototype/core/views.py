import os, time, uuid, json, io
from pathlib import Path
from datetime import datetime

import boto3
import fitz            # PyMuPDF
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.db.models import Avg

from openai import OpenAI
from .models import Document, Message


# ────────── Config / clients ──────────
client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY"),
    default_headers={"OpenAI-Beta": "assistants=v2"},
)

# Environment variable configs
VECTOR_ID    = os.getenv("VECTOR_ID")
ASSISTANT_ID = os.getenv("ASSISTANT_ID")
AWS_BUCKET   = os.getenv("AWS_STORAGE_BUCKET_NAME")

s3 = boto3.client("s3") # Boto3 client for accessing S3

# ────────── 1. Presign upload (browser → S3) ──────────
@require_POST
@csrf_exempt
def presign(request):
    # Generate unique S3 key for upload
    key = f"uploads/{uuid.uuid4()}.pdf"
    # Create a presigned POST so the browser can upload directly to S3
    presigned = s3.generate_presigned_post(
        Bucket=AWS_BUCKET,
        Key=key,
        Conditions=[["content-length-range", 1, 15_000_000]], # 15MB max
        ExpiresIn=300,
    )
    return JsonResponse({"key": key, "presigned": presigned})


# ────────── 2. Browser notifies Django after upload ──────────
@csrf_exempt
def notify_upload(request):
    data = json.loads(request.body)
    key  = data["key"]         # S3 object key
    name = data["filename"]    # original filename

    # Save document metadata to database
    doc = Document.objects.create(
        file=name,
        s3_key=key,
    )

    # Create a new assistant thread for follow-up Q&A later
    thread = client.beta.threads.create()
    doc.thread_id = thread.id
    doc.save(update_fields=["thread_id"])

    return JsonResponse({"doc_id": doc.id})


# ────────── 3. Fast summary (PyMuPDF + GPT-4o) ──────────
def summarize_fast(request, doc_id):
    try:
        doc = get_object_or_404(Document, id=doc_id)
        print(f"[INFO] Summarizing doc_id={doc.id}, s3_key={doc.s3_key}")

        if not doc.s3_key:
            return JsonResponse({
                "status": "error",
                "message": "Missing S3 key for document."
            }, status=400)

        # Step 1: Download from S3
        t0 = time.perf_counter()
        obj = s3.get_object(Bucket=AWS_BUCKET, Key=doc.s3_key)
        pdf_bytes = obj["Body"].read()

        # Step 2: Extract all text using PyMuPDF
        with fitz.open(stream=pdf_bytes, filetype="pdf") as pdf:
            full_text = "\n".join(page.get_text() for page in pdf)
            num_pages = pdf.page_count

        # Step 3: Truncate for speed/cost (6000 characters)
        truncated_text = full_text[:6000]

        # Step 4: Ask GPT-4o to summarize in 5 bullets
        resp = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "Summarize the following document in 5 bullet points."},
                {"role": "user", "content": truncated_text},
            ]
        )

        summary = resp.choices[0].message.content
        latency_ms = round((time.perf_counter() - t0) * 1000)

        # Step 5: Save summary to DB + latency metric
        Message.objects.create(document=doc, role="assistant", content=summary)
        doc.latency_ms = latency_ms
        doc.save(update_fields=["latency_ms"])

        print(f"[SUMMARY] doc_id={doc.id}, pages={num_pages}, latency={latency_ms} ms")

        return JsonResponse({
            "status": "ok",
            "response": summary,
            "latency_ms": latency_ms
        })

    except Exception as e:
        import traceback
        traceback.print_exc()
        return JsonResponse({
            "status": "error",
            "message": str(e)
        }, status=500)


# ────────── 4. Assistant summary (file_search) ──────────
def summarize(request, doc_id):
    if request.method != "POST":
        return JsonResponse({"error": "Invalid request method"}, status=405)

    doc = get_object_or_404(Document, id=doc_id)
   
    # Avoid duplicate run if previous one is still active
    active = client.beta.threads.runs.list(thread_id=doc.thread_id).data
    if any(r.status in {"queued", "in_progress"} for r in active):
        return JsonResponse({"status": "already_running"})

    # Ask assistant to summarize using file_search (doc must already be indexed via thread)
    client.beta.threads.messages.create(
        thread_id=doc.thread_id,
        role="user",
        content="Please summarise this document in 5 bullet points.",
    )

    run = client.beta.threads.runs.create(
        thread_id=doc.thread_id,
        assistant_id=ASSISTANT_ID,
        temperature=0,
    )

    doc.run_id = run.id
    doc.save(update_fields=["run_id"])
    print("Started run:", run.id, "for thread:", doc.thread_id)

    return JsonResponse({"status": "started"})


# ────────── 5. Poll assistant run (until summary is ready) ──────────
def poll_run(request, doc_id):
    doc = get_object_or_404(Document, id=doc_id)
    run = client.beta.threads.runs.retrieve(run_id=doc.run_id)

    if run.status == "completed":
        msgs = client.beta.threads.messages.list(thread_id=doc.thread_id).data
        for m in reversed(msgs):
            if m.role == "assistant":
                msg = m.content[0].text.value
                Message.objects.create(document=doc, role="assistant", content=msg)
                return JsonResponse({"status": "completed", "response": msg})
        return JsonResponse({"status": "error", "message": "No assistant reply found."})

    if run.status in {"queued", "in_progress"}:
        return JsonResponse({"status": "running"})

    return JsonResponse({"status": "error", "message": run.status})


# ────────── 6. Chat Q&A (Follow-up questions to same document) ──────────
def chat(request, doc_id):
    doc  = get_object_or_404(Document, id=doc_id)
    msgs = Message.objects.filter(document=doc).order_by("created_at")

    if request.method == "POST":
        q = request.POST.get("question", "").strip()
        if q:
            Message.objects.create(document=doc, role="user", content=q)

            # Avoid overlapping runs
            if any(r.status in {"queued", "in_progress"}
                   for r in client.beta.threads.runs.list(thread_id=doc.thread_id).data):
                return JsonResponse({"error": "Assistant busy"}, status=400)

            # Use create_and_poll for blocking call until answer is ready
            run = client.beta.threads.runs.create_and_poll(
                thread_id=doc.thread_id,
                assistant_id=ASSISTANT_ID,
                temperature=0,
            )

            if run.status == "completed":
                msgs = client.beta.threads.messages.list(thread_id=doc.thread_id).data
                answer = next((m.content[0].text.value for m in reversed(msgs)
                               if m.role == "assistant"), "[No reply]")
            else:
                answer = f"[Run error: {run.status}]"

            Message.objects.create(document=doc, role="assistant", content=answer)
            return redirect("chat", doc_id=doc.id)

    return render(request, "chat.html", {"doc": doc, "msgs": msgs})


# ────────── 7. Metrics view (average latency from summarize_fast) ──────────
def metrics(request):
    qs = Document.objects.exclude(latency_ms=None)
    return JsonResponse({
        "count": qs.count(),
        "avg_ms": qs.aggregate(Avg("latency_ms"))["latency_ms__avg"],
    })
    
# ────────── Upload UI page ──────────   
def upload_page(request):
    """Render the new browser-→S3 upload form."""
    return render(request, "upload.html")
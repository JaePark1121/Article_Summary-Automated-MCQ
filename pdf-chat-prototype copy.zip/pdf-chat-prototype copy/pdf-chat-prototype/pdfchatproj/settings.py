from pathlib import Path
import os
from dotenv import load_dotenv

# ─────────── Load environment variables ────────────
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")

# ─────────── Basic settings ────────────
SECRET_KEY = os.getenv("DJANGO_SECRET", "INSECURE-DEV-KEY")
DEBUG = True
ALLOWED_HOSTS: list[str] = []

# ─────────── AWS S3 configuration ────────────
AWS_ACCESS_KEY_ID        = os.getenv("AWS_ACCESS_KEY_ID")
AWS_SECRET_ACCESS_KEY    = os.getenv("AWS_SECRET_ACCESS_KEY")
AWS_STORAGE_BUCKET_NAME  = os.getenv("AWS_STORAGE_BUCKET_NAME")
AWS_S3_REGION_NAME       = os.getenv("AWS_REGION")

# Django 5.x storage syntax
STORAGES = {
    # S3 for user uploads
    "default": {
        "BACKEND": "storages.backends.s3boto3.S3Boto3Storage",
        "OPTIONS": {
            "access_key":       AWS_ACCESS_KEY_ID,
            "secret_key":       AWS_SECRET_ACCESS_KEY,
            "bucket_name":      AWS_STORAGE_BUCKET_NAME,
            "region_name":      AWS_S3_REGION_NAME,
            "querystring_auth": False,
            "file_overwrite":   False,
            "default_acl":      None,
        },
    },
    # keep static files on the local filesystem during development
    "staticfiles": {
        "BACKEND": "django.contrib.staticfiles.storage.StaticFilesStorage",
    },
}


# ─────────── Applications ────────────
INSTALLED_APPS = [
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "core",
    "storages",
]

MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]

ROOT_URLCONF = "pdfchatproj.urls"

TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [],
        "APP_DIRS": True,
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]

WSGI_APPLICATION = "pdfchatproj.wsgi.application"

# ─────────── Database ────────────
DATABASES = {
    "default": {
        "ENGINE":   "django.db.backends.postgresql",
        "NAME":     os.getenv("DB_NAME", "pdfchat"),
        "USER":     os.getenv("DB_USER", "pdfuser"),
        "PASSWORD": os.getenv("DB_PASS", "pdfpass"),
        "HOST":     os.getenv("DB_HOST", "localhost"),
        "PORT":     os.getenv("DB_PORT", "5432"),
    }
}

# ─────────── Media & Static ────────────
MEDIA_URL  = "/media/"
MEDIA_ROOT = BASE_DIR / "media"
STATIC_URL = "static/"

# ─────────── Other settings ────────────
LANGUAGE_CODE = "en-us"
TIME_ZONE     = "UTC"
USE_I18N      = True
USE_TZ        = True
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"

# ─────────── Logging (for boto3 debug) ────────────
LOGGING = {
    "version": 1,
    "handlers": {
        "console": {"class": "logging.StreamHandler"},
    },
    "loggers": {
        "boto3":    {"handlers": ["console"], "level": "DEBUG"},
        "botocore": {"handlers": ["console"], "level": "DEBUG"},
    },
}

print("S3 bucket =", AWS_STORAGE_BUCKET_NAME)
print("Storage backend class =", STORAGES['default']['BACKEND'])

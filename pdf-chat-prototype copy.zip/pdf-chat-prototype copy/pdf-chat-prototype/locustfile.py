from locust import HttpUser, task, between
import os, time, re, json
from pathlib import Path
import requests

class UploadUser(HttpUser):
    wait_time = between(1, 2)
    host = "http://127.0.0.1:8000"  # Adjust to your server host if different

    pdfs = [
        ("Understanding Renewable Energy.pdf", "Understanding Renewable Energy.pdf"),
        ("how_can_we_predict_extreme_winter_weather.pdf", "how_can_we_predict_extreme_winter_weather.pdf"),
        ("arctic_article.pdf", "arctic_article.pdf"),
        ("Renewables for Sustainable Village Power.pdf", "Renewables for Sustainable Village Power.pdf"),
        ("Energy Dependency.pdf", "Energy Dependency.pdf"),
    ]

    @task
    def upload_and_summary(self):
        for label, filename in self.pdfs:
            filepath = Path(__file__).parent / "test_pdfs" / filename
            if not filepath.exists():
                print(f"❌ File not found: {filepath}")
                continue

            # Step 1: Get presigned URL
            with self.client.post("/presign/", name="Presign", catch_response=True) as pres_resp:
                if pres_resp.status_code != 200:
                    pres_resp.failure("Presign failed")
                    continue
                pres_data = pres_resp.json()

            # Step 2: Upload to S3 directly
            with filepath.open("rb") as f:
                fields = pres_data["presigned"]["fields"]
                url = pres_data["presigned"]["url"]
                files = {"file": (filename, f)}
                response = requests.post(url, data=fields, files=files)
                if response.status_code != 204:
                    print(f"❌ S3 upload failed for {filename}: {response.status_code}")
                    continue

            # Step 3: Notify server
            notify_payload = {
                "key": pres_data["key"],
                "filename": filename
            }
            with self.client.post("/notify-upload/", json=notify_payload, name="NotifyUpload", catch_response=True) as notify_resp:
                if notify_resp.status_code != 200:
                    notify_resp.failure("Notify failed")
                    continue
                doc_id = notify_resp.json().get("doc_id")

            # Step 4: Trigger summary
            start_summary = time.perf_counter()
            with self.client.post(f"/summarize/fast/{doc_id}/", name="FastSummary", catch_response=True) as summary_resp:
                summary_time = round((time.perf_counter() - start_summary) * 1000)
                if summary_resp.status_code != 200:
                    summary_resp.failure("Summary failed")
                    print(f"❌ Summary failed for {filename}")
                else:
                    print(f"✅ {filename}: Summary={summary_time} ms")
